
# Definition of Ready (DoR)
- Story ma opis, kryteria akceptacji, estymację i priorytet.

# Definition of Done (DoD)
- Kod pokryty testami, lint czysty, PR z review, zaktualizowana dokumentacja.
